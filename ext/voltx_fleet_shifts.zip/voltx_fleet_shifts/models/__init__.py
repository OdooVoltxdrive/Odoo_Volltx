from . import fleet_vehicle
from . import fleet_vehicle_log_contract
from . import fleet_vehicle_driver_history
from . import fleet_weekly_liquidation
from . import res_partner
